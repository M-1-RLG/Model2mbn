﻿using System;
using model2mbn.IO;
using Assimp;
using System.Linq;
using System.Collections.Generic;
using System.Numerics;
using System.IO;

namespace model2mbn
{
    class Program
    {
        static void Main(string[] args)
        {
            if (args.Count() >= 1)
            {

                Scene scene;
                AssimpContext Importer = new AssimpContext();

                var Flags = PostProcessSteps.None;
                Flags |= PostProcessSteps.JoinIdenticalVertices;
                Flags |= PostProcessSteps.Triangulate;

                scene = Importer.ImportFile(args[0], Flags);
                //Bones
                var bones = GetBones(scene);
                //Bone Names
                var BoneNames = new List<string>();
                //Mesh bone indices
                var MeshBTables = new List<List<string>>();

                foreach (var b in bones)
                    BoneNames.Add(b.Name);

                var f = new FileOutput();//file

                //Header
                f.writeShort(6);//Version
                f.writeShort(-1);//Padding
                f.writeUInt(1);//Mesh flags
                f.writeUInt(0);//Vertex flags

                f.writeInt(scene.Meshes.Count);//Mesh count
                //End Header---------------------------------------------------------------


                //Vertex Attributes/Mesh Data
                foreach(var mesh in scene.Meshes)
                {
                    //Get this meshes vertex attributes
                    List<VertexAttribute> Attributes = GetAttributes(mesh);
                    List<string> BoneTable = new List<string>();


                    f.writeInt(1);//Submesh count
                    if(mesh.HasBones)
                    {
                        f.writeInt(mesh.Bones.Count);//BoneTable count
                        foreach (var bone in mesh.Bones)
                        {
                            if (BoneNames.Contains(bone.Name))
                                f.writeInt(BoneNames.IndexOf(bone.Name));
                            else
                                f.writeInt(0);

                            BoneTable.Add(bone.Name);
                        }
                        MeshBTables.Add(BoneTable);
                    }

                    //Face(s) count
                    f.writeInt(mesh.FaceCount*3);
                    f.writeInt(Attributes.Count);

                    //Write Vertex Attributes
                    foreach (var va in Attributes)
                        va.Write(f);

                    f.writeInt(mesh.Vertices.Count * CalcBufferSize(Attributes));
                }

                var i = 0;
                foreach(var mesh in scene.Meshes)
                {
                    List<VertexAttribute> Attributes = GetAttributes(mesh);

                    f.align(32, -1);
                    WriteVertexBuffer(f, mesh, Attributes, MeshBTables[i]);
                    f.align(32, -1);

                    foreach (var faces in mesh.Faces)
                    {
                        f.writeUShort((ushort)faces.Indices[0]);
                        f.writeUShort((ushort)faces.Indices[1]);
                        f.writeUShort((ushort)faces.Indices[2]);
                    }
                    f.align(32, -1);

                    i++;
                }

                f.save($@"{Path.GetDirectoryName(args[0])}\\output.mbn");
            }
        }

        private static int CalcBufferSize(List<VertexAttribute> attributes)
        {
            //TODO: Finish this and do it properly
            var i = 0;
            foreach (var a in attributes)
            {
                switch (a.DataType)
                {
                    case DataType.SByte:
                        if (a.Attribute == AttributeType.Position || a.Attribute == AttributeType.Normal)
                            i += sizeof(sbyte) * 3;
                        else if (a.Attribute == AttributeType.Color)
                            i += sizeof(sbyte) * 4 +1;
                        else
                            i += sizeof(sbyte) * 2;
                        break;
                    case DataType.Byte:
                        if (a.Attribute == AttributeType.Position || a.Attribute == AttributeType.Normal)
                            i += sizeof(byte) * 3;
                        else if (a.Attribute == AttributeType.Color)
                            i += sizeof(byte) * 4 + 1;
                        else
                            i += sizeof(byte) * 2;
                        break;
                    case DataType.Float:
                        if (a.Attribute == AttributeType.Position || a.Attribute == AttributeType.Normal)
                            i += sizeof(float) * 3;
                        else if (a.Attribute == AttributeType.Color)
                            i += sizeof(float) * 4 + 1;
                        else
                            i += sizeof(float) * 2;
                        break;
                    case DataType.SShort:
                        if (a.Attribute == AttributeType.Position || a.Attribute == AttributeType.Normal)
                            i += sizeof(short) * 3;
                        else if(a.Attribute == AttributeType.Color)
                            i += sizeof(short) * 4 + 1;
                        else
                            i += sizeof(short) * 2;
                        break;
                }
            }

            return i;
        }

        public static void WriteDataType(FileOutput f, VertexAttribute Type, float value)
        {
            switch (Type.DataType)
            {
                case DataType.SByte:
                    f.writeSByte(Convert.ToSByte(value));
                    break;
                case DataType.Byte:
                    f.writeByte(Convert.ToByte(value));
                    break;
                case DataType.Float:
                    f.writeFloat(value);
                    break;
                case DataType.SShort:
                    f.writeShort(Convert.ToInt16(value));
                    break;
            }
        }

        private static List<VertexAttribute> GetAttributes(Mesh mesh)
        {
            var va = new List<VertexAttribute>();

            //Position
            va.Add(new VertexAttribute()
            {
                Attribute = AttributeType.Position,
                DataType = DataType.Float,
                Scale = 0.01f
            });

            if (mesh.HasNormals)
            {
                va.Add(new VertexAttribute()
                {
                    Attribute = AttributeType.Normal,
                    DataType = DataType.SByte,
                    Scale = 0.007874f
                });
            }
            if (mesh.HasVertexColors(0))
            {
                va.Add(new VertexAttribute()
                {
                    Attribute = AttributeType.Color,
                    DataType = DataType.Byte,
                    Scale = 0.003921568627451f
                });
            }
            if (mesh.HasTextureCoords(0))
            {
                va.Add(new VertexAttribute()
                {
                    Attribute = AttributeType.UV0,
                    DataType = DataType.SShort,
                    Scale = 0.0003092868f
                });
            }
            if (mesh.HasTextureCoords(1))
            {
                va.Add(new VertexAttribute()
                {
                    Attribute = AttributeType.UV1,
                    DataType = DataType.SShort,
                    Scale = 0.0003092868f
                });
            }
            if (mesh.HasBones)
            {
                va.Add(new VertexAttribute()
                {
                    Attribute = AttributeType.BoneIndices,
                    DataType = DataType.Byte,
                    Scale = 1f
                });

                va.Add(new VertexAttribute()
                {
                    Attribute = AttributeType.BoneWeights,
                    DataType = DataType.Byte,
                    Scale = 0.01f
                });
            }
            if (mesh.HasTextureCoords(2))
            {
                va.Add(new VertexAttribute()
                {
                    Attribute = AttributeType.UV0,
                    DataType = DataType.SShort,
                    Scale = 0.0003092868f
                });
            }

            return va;
        }

        private static void WriteVertexBuffer(FileOutput f, Mesh mesh, List<VertexAttribute> attributes, List<string> BTable)
        {
            List<Vector3D> Positions = mesh.Vertices;
            List<Vector3D> Normals = mesh.Normals;
            List<Color4D> Colors = mesh.VertexColorChannels[0];
            List<Vector3D> UV0 = mesh.TextureCoordinateChannels[0];
            List<Vector3D> UV1 = mesh.TextureCoordinateChannels[1];
            List<Vector3D> UV2 = mesh.TextureCoordinateChannels[2];
            List<Vector4> Indices = new List<Vector4>();
            List<Vector4> Weights = new List<Vector4>();

            //Get weights/indices
            if (mesh.HasBones)
            {
                var BIndices = new List<List<int>>();
                var BWeights = new List<List<float>>();

                for (int i = 0; i < Positions.Count; i++)
                {
                    BIndices.Add(new List<int>());
                    BWeights.Add(new List<float>());
                }

                foreach (var b in mesh.Bones)
                {
                    foreach (var w in b.VertexWeights)
                    {
                        BIndices[w.VertexID].Add(BTable.IndexOf(b.Name));
                        BWeights[w.VertexID].Add(w.Weight);
                    }
                }

                for (int i = 0; i < Positions.Count; i++)
                {
                    if (BIndices[i].Count > 0)
                    {
                        var bi = new Vector4();
                        var bw = new Vector4();
                        //X
                        if (BIndices[i].Count >= 1){
                            bi.X = BIndices[i][0];
                            bw.X = BWeights[i][0];
                        }
                        //Y
                        if (BIndices[i].Count >= 2){
                            bi.Y = BIndices[i][1];
                            bw.Y = BWeights[i][1];
                        }
                        //Z
                        if (BIndices[i].Count >= 3){
                            bi.Z = BIndices[i][2];
                            bw.Z = BWeights[i][2];
                        }
                        //W
                        if (BIndices[i].Count >= 4){
                            bi.W = BIndices[i][3];
                            bw.W = BWeights[i][3];
                        }

                        Indices.Add(bi);
                        Weights.Add(bw);
                    }
                }
            }

            for (int i = 0; i < Positions.Count; i++)
            {
                foreach (var va in attributes)
                {
                    if (va.Attribute == AttributeType.Position){
                        WriteDataType(f, va, Positions[i].X * 100 / 3.33f);
                        WriteDataType(f, va, Positions[i].Y * 100 / 3.33f);
                        WriteDataType(f, va, Positions[i].Z * 100 / 3.33f);
                    }

                    if (va.Attribute == AttributeType.Normal){
                        WriteDataType(f, va, Normals[i].X * 127);
                        WriteDataType(f, va, Normals[i].Y * 127);
                        WriteDataType(f, va, Normals[i].Z * 127);
                    }

                    if (va.Attribute == AttributeType.Color){
                        
                        WriteDataType(f, va, Colors[i].R * 255);
                        WriteDataType(f, va, Colors[i].G * 255);
                        WriteDataType(f, va, Colors[i].B * 255);
                        WriteDataType(f, va, Colors[i].A * 255);
                        f.writeByte(0);
                    }

                    if (va.Attribute == AttributeType.UV0){
                        WriteDataType(f, va, UV0[i].X / 0.0003092868f);
                        WriteDataType(f, va, UV0[i].Y / 0.0003092868f);
                    }

                    if (va.Attribute == AttributeType.UV1){
                        WriteDataType(f, va, UV1[i].X / 0.0003092868f);
                        WriteDataType(f, va, UV1[i].Y / 0.0003092868f);
                    }

                    if (va.Attribute == AttributeType.UV2){
                        WriteDataType(f, va, UV2[i].X / 0.0003092868f);
                        WriteDataType(f, va, UV2[i].Y / 0.0003092868f);
                    }

                    if (va.Attribute == AttributeType.BoneIndices){

                        //Indices
                        WriteDataType(f, va, Indices[i].X);
                        WriteDataType(f, va, Indices[i].Y);
                        //WriteDataType(f, va, Indices[i].Z);
                        //WriteDataType(f, va, Indices[i].W);

                        //Weights
                        WriteDataType(f, va, Weights[i].X * 100);
                        WriteDataType(f, va, Weights[i].Y * 100);
                        //WriteDataType(f, va, Weights[i].Z);
                        //WriteDataType(f, va, Weights[i].W);
                    }
                }
            }
        }

        //Getting assimp bones is a hell
        #region Getting Skeleton
        private static List<Bone> GetBones(Scene scene)
        {
            var Node = scene.RootNode.FindNode("TopJoint");
            var bones = new List<Bone>();
            var Bnames = new List<string>();

            if (Node != null)
            {
                Assimp.Matrix4x4 input = Node.Transform;
                OpenTK.Matrix4 Transform = new OpenTK.Matrix4(input.A1, input.B1, input.C1, input.D1,
                                              input.A2, input.B2, input.C2, input.D2,
                                              input.A3, input.B3, input.C3, input.D3,
                                              input.A4, input.B4, input.C4, input.D4);

                OpenTK.Vector3 Rotation = ToEulerAngles(Transform.ExtractRotation());
                OpenTK.Vector3 Translation = Transform.ExtractTranslation();

                Bnames.Add("TopJoint");

                bones.Add(new Bone()
                {
                    ID = 0,
                    ParentID = -1,
                    Scale = Vector3.One,
                    Translation = new Vector3(Translation.X, Translation.Y, Translation.Z),
                    Rotation = new Vector3(Rotation.X, Rotation.Y, Rotation.Z),
                    Name = Node.Name
                });

                if(Node.HasChildren)
                {
                    foreach (var b in Node.Children){
                        GetBone(b, bones, Bnames, scene);
                    }
                }

                var Names = new List<string>();

                foreach (var b in bones){
                    Names.Add(b.Name);
                }

                foreach (var b in bones){
                    b.ParentID = Names.IndexOf(b.ParentName);
                }
            }
            return bones;
        }

        private static void GetBone(Node node, List<Bone> bones, List<string> bnames, Scene scene)
        {
            Node Parent = scene.RootNode.FindNode(node.Parent.Name);
            Assimp.Matrix4x4 input = node.Transform;
            OpenTK.Matrix4 Transform = new OpenTK.Matrix4(input.A1, input.B1, input.C1, input.D1,
                                          input.A2, input.B2, input.C2, input.D2,
                                          input.A3, input.B3, input.C3, input.D3,
                                          input.A4, input.B4, input.C4, input.D4);

            OpenTK.Vector3 Rotation = ToEulerAngles(Transform.ExtractRotation());
            OpenTK.Vector3 Translation = Transform.ExtractTranslation();

            bnames.Add(node.Name);
            bones.Add(new Bone()
            {
                ID = bnames.IndexOf(node.Name),
                ParentName = Parent.Name,
                Translation = new Vector3(Translation.X, Translation.Y, Translation.Z),
                Rotation = new Vector3(Rotation.X, Rotation.Y, Rotation.Z),
                Scale = Vector3.One,
                Name = node.Name
            });

            if (node.HasChildren)
            {
                foreach (var b in node.Children)
                {
                    GetBone(b, bones, bnames, scene);
                }
            }
        }

        private static OpenTK.Vector3 ToEulerAngles(OpenTK.Quaternion q)
        {
            OpenTK.Matrix4 mat = OpenTK.Matrix4.CreateFromQuaternion(q);
            float x, y, z;
            y = (float)Math.Asin(Clamp(mat.M13, -1, 1));

            if (Math.Abs(mat.M13) < 0.99999)
            {
                x = (float)Math.Atan2(-mat.M23, mat.M33);
                z = (float)Math.Atan2(-mat.M12, mat.M11);
            }
            else
            {
                x = (float)Math.Atan2(mat.M32, mat.M22);
                z = 0;
            }
            return new OpenTK.Vector3(x, y, z) * -1;
        }

        private static float Clamp(float v, float min, float max)
        {
            if (v < min) return min;
            if (v > max) return max;
            return v;
        }
        #endregion
    }
}
